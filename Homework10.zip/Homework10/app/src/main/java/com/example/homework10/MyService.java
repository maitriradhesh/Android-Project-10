package com.example.homework10;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.widget.Toast;

public class MyService extends Service {

    private MyAsyncTask asyncTask;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        asyncTask = new MyAsyncTask();
        asyncTask.execute();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        if (asyncTask != null) {
            asyncTask.cancel(true);
        }
        super.onDestroy();
    }

    private class MyAsyncTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            for (int i = 0; i <= 100; i += 10) {
                if (isCancelled()) {
                    break;
                }
                publishProgress(i);
                try {
                    Thread.sleep(500); // Simulating a download task
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            Intent intent = new Intent("PROGRESS_UPDATE");
            intent.putExtra("progressValue", values[0]);
            sendBroadcast(intent);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            stopSelf();
        }
    }
}